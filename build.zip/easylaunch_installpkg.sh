#!/bin/sh
npm i