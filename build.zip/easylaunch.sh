#!/bin/sh
npx electron .